const mongoose = require("mongoose")


const message = new mongoose.Schema({

    
    
    key:{
        type : String,
        
    },
  
   
    message:{
        type : String,
        
    },
    status:{
        type : String,
        default: "pending"
    },
    
   
  
});

 module.exports = Message = new mongoose.model("Message",message);
//  export default Message;