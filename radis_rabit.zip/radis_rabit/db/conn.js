
// import mongoose from "mongoose";

const mongoose = require("mongoose")


const CONNECTION_URL = `mongodb+srv://satya123sp34:fRGaITT0KzJGli2M@cluster0.jiimvbp.mongodb.net/test`
mongoose.set("strictQuery", false);
mongoose.connect(CONNECTION_URL,{useNewUrlParser:true,useUnifiedTopology:true})
.then(()=>console.log("mongodb connected successfully"))
.catch((err)=>console.log(err));