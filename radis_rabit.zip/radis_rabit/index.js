const express = require("express")
const bodyParser = require("body-parser")
const path = require("path")
const amqp = require("amqplib")
const Message = require("./schema/schema.js")
const nodemailer = require('nodemailer');
const redis = require('redis');
const redisClient = redis.createClient();

require("./db/conn.js");
require("./redis/redis.js");

(async () => {
    await redisClient.connect();
})();

redisClient.on('connect', () => console.log('Redis Client Connected'));
redisClient.on('error', (err) => console.log('Redis Client Connection Error', err));
let transporter = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 2525,
    auth: {
        user: "1a95db15d3365d",
        pass: "156aee728cd551"
    }
});

const app = express();
const PORT = 8000;



app.use(express.urlencoded({
    extended: true
}));
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')




async function startConsumer() {

    const connection = await amqp.connect('amqp://localhost');
    const channel = await connection.createChannel();
    const queueName = 'form-data-queue';

    await channel.assertQueue(queueName, { durable: true });
    await channel.prefetch(1);

    console.log('Consumer started, waiting for messages...');

    channel.consume(queueName, async (msg) => {


        try {

            const emailData = JSON.parse(msg.content.toString());

            const key = emailData.key
            const message = emailData.message

            let mailOptions = {
                from: 'satya123.sp34@gmail.com', // sender address
                to: key, // list of receivers
                subject: 'Hello from Node.js!', // Subject line
                text: message, // plain text body
                html: '<b>Hello world!</b>' // html body
            };


            transporter.sendMail(mailOptions, async (error, info) => {
                if (error) {
                    return console.log(error);
                }

                const dbdata = await Message.findOneAndUpdate({ key }, { status: 'fullfilled' }, {
                    new: true
                })

                console.log(dbdata)

                console.log('Message sent: %s', info.messageId);
            });



            console.log('Saved form data to Redis:', emailData);

            channel.ack(msg);
        } catch (err) {
            console.error('Error processing message:', err);
            channel.reject(msg, true);
        }
    });
}


async function producer(queueName, data) {

    try {
        const connection = await amqp.connect('amqp://localhost');
        const channel = await connection.createChannel();

        await channel.assertQueue(queueName, { durable: true });
        await channel.sendToQueue(queueName, Buffer.from(JSON.stringify(data)), { persistent: true });

        const { key, message } = data

        if (redisClient.get('keyval')) {
            const data = await redisClient.del('keyval')
            console.log(data)
        }
        //saving to db 
        const dbdata = new Message({ key, message })
        console.log(dbdata)
        await dbdata.save();

        await channel.close();
        await connection.close();

    } catch (err) {
        console.error('Error sending message to RabbitMQ:', err);

    }


}


startConsumer().catch((err) => {
    console.error('Error starting consumer:', err);
});


app.get('/', async function (req, res) {


    res.sendFile('views/test.html', { root: __dirname })

})

app.post("/receive", async (req, res) => {

    console.log(req.body)
    const queueName = 'form-data-queue';
    await producer(queueName, req.body)

    return res.redirect("/table")

})


app.get("/send", async (req, res) => {

    let key = 'keyval'



    await redisClient.expire('keyval', 30)

    const data = await Message.find()
    const keyval = await redisClient.get('keyval')

    if (!keyval) {
        const setval = await redisClient.set('keyval', JSON.stringify(data))
        console.log(setval)
    }

    let jsondata = (await redisClient.get('keyval'))

    console.log(jsondata)
    return res.status(404).json({ jsondata });


})


app.get("/table", async (req, res) => {

    return res.sendFile('views/table.html', { root: __dirname })

})


app.listen(PORT, () => {
    console.log(`server running successfully on PORT : ${PORT}`)
});